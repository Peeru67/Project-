package com.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Result {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    private String email;
    private String jobTitle;
    private String result;
    private String empEmail;
    
    public Result(){
    	
    }

	public Result(String email, String jobTitle, String result, String empEmail) {
		super();
		this.email = email;
		this.jobTitle = jobTitle;
		this.result = result;
		this.empEmail = empEmail;
	}

	public Result(long id, String email, String jobTitle, String result, String empEmail) {
		super();
		this.id = id;
		this.email = email;
		this.jobTitle = jobTitle;
		this.result = result;
		this.empEmail = empEmail;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getJobTitle() {
		return jobTitle;
	}

	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public String getEmpEmail() {
		return empEmail;
	}

	public void setEmpEmail(String empEmail) {
		this.empEmail = empEmail;
	}

	
    
}    