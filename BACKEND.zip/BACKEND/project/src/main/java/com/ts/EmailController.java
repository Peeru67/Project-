package com.ts;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.Random;

@RestController
public class EmailController {

    private final JavaMailSender mailSender;

    @Autowired
    public EmailController(JavaMailSender mailSender) {
        this.mailSender = mailSender;
    }

    @GetMapping("/sendemail/{email}")
    public String sendEmail(@PathVariable String email) {
        // Generate random 4-digit verification code
        Random random = new Random();
        int verificationCode = 1000 + random.nextInt(9000);

        // Send email
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(email);
        message.setSubject("Email Verification Code");
        message.setText("Your verification code is: " + verificationCode);
        
        mailSender.send(message);

        return "{\"verificationCode\": " + verificationCode + "}";
    }
}
