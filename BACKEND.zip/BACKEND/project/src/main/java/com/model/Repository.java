package com.model;

public class Repository {

}
