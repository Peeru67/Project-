// ResultDao.java

package com.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.model.Result;

@Service
public class ResultDao {

    @Autowired
    private ResultRepository resultRepository;

    // Save result
    public Result saveResult(Result result) {
        return resultRepository.save(result);
    }

    // Retrieve all results
    public List<Result> getResults() {
        return resultRepository.findAll();
    }

    // Retrieve results by empEmail
    public List<Result> getResultsByEmpEmail(String empEmail) {
        return resultRepository.findByEmpEmail(empEmail);
    }
}
