package com.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.model.Result;

@Repository
public interface ResultRepository extends JpaRepository<Result, Long> {

    // Sample query method to find results by empEmail
    List<Result> findByEmpEmail(String empEmail);
}
