// EmployerDbDao.java
package com.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.model.EmployerDb;
import com.model.Jobseeker;

@Service
public class EmployerDbDao {
    private final JobseekerDao jobseekerDao;
    private final JavaMailSender mailSender;

    private final EmployerDbRepository employerDbRepository;

    @Autowired
    public EmployerDbDao(JobseekerDao jobseekerDao, JavaMailSender mailSender,
            EmployerDbRepository employerDbRepository) {
        this.jobseekerDao = jobseekerDao;
        this.mailSender = mailSender;
        this.employerDbRepository = employerDbRepository;
    }

    public List<EmployerDb> getEmployerDbs() {
        return employerDbRepository.findAll();
    }

    public EmployerDb getEmployerDbById(int EmployerDbId) {
        return employerDbRepository.findById(EmployerDbId).orElse(null);
    }

    public EmployerDb getEmployerDbByName(String EmployerDbName) {
        return employerDbRepository.findByName(EmployerDbName);
    }

    public EmployerDb addEmployerDb(EmployerDb employerDb) {
        EmployerDb savedEmployerDb = employerDbRepository.save(employerDb);
        sendEmailsToJobSeekers(savedEmployerDb); // Send email notifications to job seekers
        return savedEmployerDb;
    }

    public EmployerDb updateEmployerDb(EmployerDb employerDb) {
        return employerDbRepository.save(employerDb);
    }

    public void deleteEmployerDbById(int EmployerDbId) {
        employerDbRepository.deleteById(EmployerDbId);
    }

    private void sendEmailsToJobSeekers(EmployerDb employerDb) {
        List<Jobseeker> jobseekers = jobseekerDao.getJobseekers();
        for (Jobseeker jobseeker : jobseekers) {
            sendJobNotificationEmail(jobseeker, employerDb);
        }
    }

    private void sendJobNotificationEmail(Jobseeker jobseeker, EmployerDb employerDb) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(jobseeker.getEmail());
        message.setSubject("New Job Opportunity: " + employerDb.getJobTitle());
        message.setText("Dear " + jobseeker.getUname() + ",\n\n" + "A new job opportunity is available: "
                + employerDb.getJobTitle() + "\n" + "Job Description: " + employerDb.getJobDescription() + "\n"
                + "Please login to our platform for more details.\n\n" + "Best regards,\n" + "Talent Trek Team");

        mailSender.send(message);
    }
}
