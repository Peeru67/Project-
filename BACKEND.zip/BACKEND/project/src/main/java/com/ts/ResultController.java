// ResultController.java

package com.ts;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dao.ResultDao;
import com.model.Result;

@RestController
public class ResultController {

    @Autowired
    private ResultDao resultDao;

    // Save result
    @PostMapping("/saveResult")
    public Result saveResult(@RequestBody Result result) {
        return resultDao.saveResult(result);
    }

    // Retrieve all results
    @GetMapping("/getResults")
    public List<Result> getResults() {
        return resultDao.getResults();
    }

    // Retrieve results by empEmail
    @GetMapping("/getResultsByEmpEmail")
    public List<Result> getResultsByEmpEmail(@RequestParam String empEmail) {
        return resultDao.getResultsByEmpEmail(empEmail);
    }
}
