	package com.dao;
	
	import java.util.List;
	
	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.mail.SimpleMailMessage;
	import org.springframework.mail.javamail.JavaMailSender;
	import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
	import org.springframework.stereotype.Service;
	
	import com.model.Employer;
	import com.model.Jobseeker;
	
	@Service
	public class JobseekerDao {
		
		@Autowired
		JobseekerRepository jobseekerRepository;
		
		@Autowired
		private JavaMailSender mailSender;
	
		public List<Jobseeker> getJobseekers() {
			return jobseekerRepository.findAll();
		}
	
		public Jobseeker getJobseekerById(int jobseekerId) {
			return jobseekerRepository.findById(jobseekerId).orElse(null);
		}
	
		public Jobseeker getJobseekerByName(String jobseekerName) {
			return jobseekerRepository.findByName(jobseekerName);
		}
	
		public Jobseeker addJobseeker(Jobseeker jobseeker) {
			BCryptPasswordEncoder bcrypt = new BCryptPasswordEncoder();
	        String encryptedPwd = bcrypt.encode(jobseeker.getPassword());
	        jobseeker.setPassword(encryptedPwd);
	        Jobseeker savedjobseeker = jobseekerRepository.save(jobseeker);
	        sendWelcomeEmail(savedjobseeker);
	        return savedjobseeker;
		}
		 private void sendWelcomeEmail(Jobseeker jobseeker) {
				
				SimpleMailMessage message = new SimpleMailMessage();
				message.setTo(jobseeker.getEmail());	
				message.setSubject("Welcome to Talent Trek");
				message.setText("Dear " + jobseeker.getUname() + ",\n\n"
						+ "Thank you for registering ");
	
				mailSender.send(message);
			}
		 public void sendemail(String email) {
		        SimpleMailMessage message = new SimpleMailMessage();
		        message.setTo(email);
		        message.setSubject("Welcome to Talent Trek");
		        message.setText("Dear Job Seeker,\n\nThank you for registering with Talent Trek.");
	
		        mailSender.send(message);
		    }	
	
		public Jobseeker updateJobseeker(Jobseeker jobseeker) {
			return jobseekerRepository.save(jobseeker);
		}
	
		public void deleteJobseekerById(int jobseekerId) {
			jobseekerRepository.deleteById(jobseekerId);
		}
		
		public Jobseeker jobseekerLogin(String email, String password){
			return jobseekerRepository.jobseekerLogin(email,password);
		}
		
	}
