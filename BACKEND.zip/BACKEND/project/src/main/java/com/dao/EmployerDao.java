package com.dao;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.model.Employer;

@Service
public class EmployerDao {

	@Autowired
	EmployerRepository employerRepository;
	
	@Autowired
	private JavaMailSender mailSender;

	public List<Employer> getEmployers() {
		return employerRepository.findAll();
	}

	public Employer getEmployerById(int employerId) {
		return employerRepository.findById(employerId).orElse(null);
	}

	public Employer getEmployerByName(String employerName) {
		return employerRepository.findByName(employerName);
	}

	public Employer addEmployer(Employer employer) {
		BCryptPasswordEncoder bcrypt = new BCryptPasswordEncoder();
        String encryptedPwd = bcrypt.encode(employer.getPassword());
        employer.setPassword(encryptedPwd);
        Employer savedEmployer = employerRepository.save(employer);
        sendWelcomeEmail(savedEmployer);
        return savedEmployer;
	}
    private void sendWelcomeEmail(Employer employer) {
		
			SimpleMailMessage message = new SimpleMailMessage();
			message.setTo(employer.getEmail());
			message.setSubject("Welcome to Talent Trek");
			message.setText("Dear " + employer.getEmpName() + ",\n\n"
					+ "Thank you for registering ");

			mailSender.send(message);
		}
	public Employer updateEmployer(Employer employer) {
		return employerRepository.save(employer);
	}
	
	public Employer employerLogin(String emailId, String password) {
		return employerRepository.employerLogin(emailId, password);
	}

	public void deleteEmployerById(int employerId) {
		employerRepository.deleteById(employerId);
	}
	
}
